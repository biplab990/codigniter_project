<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FormCtrl extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('FormModel','fm');
		$this->load->helper('form');
	}

		// Admission
		public function index(){
			$data['student']=$this->fm->retrive();
			$this->load->view('form/index',$data);
		}
	
		public function admission_create(){
			$this->load->helper('form');
			$this->load->library('form_validation');
			$this->form_validation->set_rules('name','Full Name','required');
			$this->form_validation->set_rules('father_name','Father Name','required');
			$this->form_validation->set_rules('mother_name','Mother Name','required');
			$this->form_validation->set_rules('contact','Contact','required');
			$this->form_validation->set_rules('ad_class','Class','required');
			$this->form_validation->set_rules('address','Address','required');
			$this->form_validation->set_rules('gender','Gender','required');
			$this->form_validation->set_rules('blood_group','Blood Group','required');
			$this->form_validation->set_rules('section','Section','required');
			$this->form_validation->set_rules('shift','Shift','required');
			$this->form_validation->set_rules('birthday','Birthday','required');
			$this->form_validation->set_rules('religion','Religion','required');
			if($this->form_validation->run() == FALSE){
				$this->load->view('form/create');
			}else{
				$st['name']=$this->input->post('name');
				$st['father_name']=$this->input->post('father_name');
				$st['mother_name']=$this->input->post('mother_name');
				$st['contact']=$this->input->post('contact');
				$st['ad_class']=$this->input->post('ad_class');
				$st['address']=$this->input->post('address');
				$st['gender']=$this->input->post('gender');
				$st['blood_group']=$this->input->post('blood_group');
				$st['section']=$this->input->post('section');
				$st['shift']=$this->input->post('shift');
				$st['birthday']=$this->input->post('birthday');
				$st['religion']=$this->input->post('religion');
				if($stu_id=$this->fm->create($st)){
					$this->pay($stu_id);
				}else{
					$this->session->set_flashdata('msg','<b class="text-danger">Please Try Again</b>');
					$this->load->view('form/create');
				}
			}
		}

		public function pay($stu_id){
			/* PHP */
			$post_data = array();
			$post_data['store_id'] = "sckre5f3556c781c85";
			$post_data['store_passwd'] = "sckre5f3556c781c85@ssl";
			$post_data['total_amount'] = "500";
			$post_data['currency'] = "BDT";
			$post_data['tran_id'] = "CAD".uniqid();
			$post_data['success_url'] = "http://localhost/project_ci_biplab/success_admission/".$post_data['tran_id']."/".$stu_id;
			$post_data['fail_url'] =  "http://localhost/project_ci_biplab/cancel_admission/".$post_data['tran_id']."/".$stu_id;
			$post_data['cancel_url'] =  "http://localhost/project_ci_biplab/cancel_admission/".$post_data['tran_id']."/".$stu_id;
			
			# $post_data['multi_card_name'] = "mastercard,visacard,amexcard";  # DISABLE TO DISPLAY ALL AVAILABLE

			# EMI INFO
			$post_data['emi_option'] = "0";
			$post_data['emi_max_inst_option'] = "0";
			$post_data['emi_selected_inst'] = "0";

			# CUSTOMER INFORMATION
			$post_data['cus_name'] = $this->input->post('name');
			$post_data['cus_email'] = "kamal@gmail.com";
			$post_data['cus_add1'] = $this->input->post('address');
			$post_data['cus_add2'] = "Dhaka";
			$post_data['cus_city'] = "Dhaka";
			$post_data['cus_state'] = "Dhaka";
			$post_data['cus_postcode'] = "1000";
			$post_data['cus_country'] = "Bangladesh";
			$post_data['cus_phone'] = $this->input->post('contact');
			$post_data['cus_fax'] = $this->input->post('contact');

			# SHIPMENT INFORMATION
			$post_data['shipping_method'] = "NO";
			$post_data['ship_name'] = "Store Test";
			$post_data['ship_add1 '] = "Dhaka";
			$post_data['ship_add2'] = "Dhaka";
			$post_data['ship_city'] = "Dhaka";
			$post_data['ship_state'] = "Dhaka";
			$post_data['ship_postcode'] = "1000";
			$post_data['ship_country'] = "Bangladesh";


			# CART PARAMETERS
			$post_data['product_name'] = "Adimission";
			$post_data['product_category'] = "None";
			$post_data['product_profile'] = "non-physical-goods";
			$post_data['cart'] = "";
			$post_data['product_amount'] = "100";
			$post_data['vat'] = "0";
			$post_data['discount_amount'] = "0";
			$post_data['convenience_fee'] = "0";
			
			
			$direct_api_url = "https://sandbox.sslcommerz.com/gwprocess/v4/api.php";

			$handle = curl_init();
			curl_setopt($handle, CURLOPT_URL, $direct_api_url );
			curl_setopt($handle, CURLOPT_TIMEOUT, 30);
			curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 30);
			curl_setopt($handle, CURLOPT_POST, 1 );
			curl_setopt($handle, CURLOPT_POSTFIELDS, $post_data);
			curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, FALSE); # KEEP IT FALSE IF YOU RUN FROM LOCAL PC


			$content = curl_exec($handle );

			$code = curl_getinfo($handle, CURLINFO_HTTP_CODE);

			if($code == 200 && !( curl_errno($handle))) {
				curl_close( $handle);
				$sslcommerzResponse = $content;
			} else {
				curl_close( $handle);
				echo "FAILED TO CONNECT WITH SSLCOMMERZ API";
				exit;
			}

			# PARSE THE JSON RESPONSE
			$sslcz = json_decode($sslcommerzResponse, true );
			
			if(isset($sslcz['GatewayPageURL']) && $sslcz['GatewayPageURL']!="" ) {
					# THERE ARE MANY WAYS TO REDIRECT - Javascript, Meta Tag or Php Header Redirect or Other
					# echo "<script>window.location.href = '". $sslcz['GatewayPageURL'] ."';</script>";
				echo "<meta http-equiv='refresh' content='0;url=".$sslcz['GatewayPageURL']."'>";
				# header("Location: ". $sslcz['GatewayPageURL']);
				exit;
			} else {
				echo "JSON Data parsing error!";
			}
		}
		
		public function success_admission($trans_id,$sid){
			$data['tran_id']=$trans_id;
			$data['paid_status']=1;
			$data['fee']=500;
			
			$this->fm->update($sid,$data);
			
			redirect('adimission_status/'.$sid."/success");
		}
		public function cancel_admission($trans_id,$sid){
			$this->fm->delete_student($sid);
			redirect('adimission_status/'.$sid."/fail");
		}
		
		public function adimission_status($sid,$status){
			if($status=="success"){
				$data=$this->fm->single_retrive($sid);
			}else{
				$data="Sorry, Please try again";
			}
			// print_r($data);
			$this->load->view('form/success');
		}
		
}
