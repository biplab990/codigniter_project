<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FontResultCtrl extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('ResultModel','rm');
		$this->load->helper('form');
	}

    public function index()
	{
		$data['results']=$this->rm->retrive();
		$this->load->view('form/result',$data);
	}
}