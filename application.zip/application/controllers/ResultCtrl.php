<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ResultCtrl extends CI_Controller {

	function __construct(){
		parent::__construct();
		/* authentication  */
		if(!$this->session->get_userdata()['ud']){
			redirect('login');
		}

		/* authorization  */
		if($this->session->get_userdata()['ud']->role_id !=1){
			redirect('/');
		}

		$this->load->model('ResultModel','rm');
		$this->load->model('CommonModel','cm');
	}
	public function index()
	{
		$data['results']=$this->rm->retrive();
		$data['page']="result/index";
		$this->load->view('app',$data);
	}
	public function create(){
		/* load helper and library */
		$this->load->helper('form');
		$data['student']=$this->cm->common_select('student_form','id,name');
		$data['page']="result/create";
		$this->load->view('app',$data);
	}
	public function store(){
		/* load helper and library */
		$this->load->helper('form');
		$this->load->library('form_validation');

		/* set validatin */
		$this->form_validation->set_rules('student_id', 'Student', 'required');
		$this->form_validation->set_rules('obtainmark', 'obtainmark', 'required');
		$this->form_validation->set_rules('position', 'Position', 'required');
		if ($this->form_validation->run() == FALSE){
			$data['page']="result/create";
			$this->load->view('app',$data);
        }else{
			$rs['student_id']=$this->input->post('student_id');
			$rs['obtainmark']=$this->input->post('obtainmark');
			$rs['position']=$this->input->post('position');
			$rs['pass_status']=1;
			if($this->rm->create($rs)){
				$this->session->set_flashdata('msg','<b class="text-success">Data saved</b>');
				redirect('result');
			}else{
				$this->session->set_flashdata('msg','<b class="text-danger">Please Try again</b>');
				$data['page']="result/create";
				$this->load->view('app',$data);
			}
		}
	}
	public function update($id){
		/* load helper and library */
		$this->load->helper('form');
		$this->load->library('form_validation');

		/* set validatin */
		$this->form_validation->set_rules('student_id', 'Student', 'required');
		$this->form_validation->set_rules('obtainmark', 'obtainmark', 'required');
		$this->form_validation->set_rules('position', 'Position', 'required');
		

		if ($this->form_validation->run() == FALSE){
			$data['student']=$this->rm->single_retrive($id);
			$data['page']="result/edit";
            $this->load->view('app',$data);
        }else{
			$rs['student_id']=$this->input->post('student_id');
			$rs['obtainmark']=$this->input->post('obtainmark');
			$rs['position']=$this->input->post('position');
			$rs['pass_status']=1;

			if($this->rm->update($id,$rs)){
				$this->session->set_flashdata('msg','<b class="text-success">Data updated</b>');
			}else{
				$this->session->set_flashdata('msg','<b class="text-danger">Please Try again</b>');
				//$this->load->view('result/edit/'.$id);
			}
			redirect('result');
        }
	}

	public function destroy($id){
		$condition['id']=$id;
		if($this->rm->delete($condition)){
			$this->session->set_flashdata('msg','<b class="text-success">Data deleted</b>');
		}else{
			$this->session->set_flashdata('msg','<b class="text-danger">Please Try again</b>');
		}

		redirect('result');
	}

}
