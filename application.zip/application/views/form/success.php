
<!doctype html>
<html>
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no"> 
		<title>Mohsin College</title>
	<!-- CSS only -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js">
	</script>
</head>

<body class="hero-anime">
	<section class="">
		<div class="container">
			<img src="<?= base_url('assets/images/heading1.png') ?>">	
			<a href="<?= base_url() ?>./" class="btn btn-primary float-end mt-5">Home</a>
				<div class="row">
				<br/>	  
					<div  align="center" class="row bg-secondary text-white"><h1> Online Admission(2021-2022)</h1></div>
                    <div class="row" style="height: 400px;">
                    <div class="col-12 mt-5" align="center">
                        <h1 class="text-warning">Congratularions !</h1>
                        <h4 class="text-success">Your Admission successfully complete.</h4>
                    </div>
                    <!-- <h1 align="center" class="mt-5 text-warning">Congratularions !</h1>
                    <p class="text-success" align="center">Your Admission successfully complete.</p> -->
                    </div>

					<!-- admission form end-->
			</div>
		</div>	
	</section>		
			
	<section class="blog_section p-0 m-0 bg-success bg-gradient">
	<!-- Footer Section -->
		
		<footer id="contact" class="bg-secondary text-white pt-3">
			<div class="container">
				<div class="row">
						<div class="col-md-4 col-sm-6">
							<h3 class="p-0 m-0">Mohsin College</h3>
								<hr class="bg-white">	
							<p><i class="fas fa-map-marker"></i>College Road, Chittagong</p>
							<p><i class="fas fa-phone"></i>Phone : 02333364690</p>
							<p><i class="fas fa-print"></i>Fax : 02333365485</p>	
							<p><i class="fas fa-mail-bulk"></i>Email : mohsincollege_ctg@yahoo.com</p>		
						</div>
						<div class="col-md-4 col-sm-6">
							<h3 class="p-0 m-0">Admission Hotline</h3>
							<hr>
							<ul>
								<p>ICT Cell Help Desk</p>
								<p>01555555140, 01555555141, 01556570077</p>
								<p>Email: admission@mohsin.ac.bd</p>
								<p>Working Hour: 9.00AM - 9.00PM</p>
							</ul>
						</div>
						<div class="col-md-4 col-sm-6">
							<h3 class="p-0 m-0">Contact Information</h3>
							<hr>
							<ul>
								<p class="mb-2">Faculty of Science:	  01555555135</p>
								<p class="mb-2">Faculty of Arts:	  01555555135</p>
								<p class="mb-2">Faculty of Commerce:	  01555555135</p>
								<p class="mb-2">Shift of Morning:	  01555555135</p>
								<p class="mb-2">Shift of Evening:	  01555555135</p>
						</div>              
				</div>
			</div>
		</footer>	

	</section>
		
		
			<!-- Jquery -->
			<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
			<!-- bootstrap -->
			<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/js/bootstrap.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
			<!-- carousel -->
			<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js"></script>	
			<script src="assets/js/bs-init.js"></script>	
</body>
</html>
