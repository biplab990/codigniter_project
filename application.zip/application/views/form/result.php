
<!doctype html>
<html>
<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no"> 
		<title>Mohsin College</title>
	<!-- CSS only -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js">
	</script>
</head>

<body class="hero-anime">
	<section class="">
		<div class="container">
			<img src="<?= base_url('assets/images/heading1.png') ?>">	
			<a href="<?= base_url() ?>./" class="btn btn-primary float-end mt-5">Home</a>
				<div class="row">
				<br/>	  
					<div  align="center" class="row bg-secondary text-white"><h1> Online Admission Result(2021-2022)</h1></div>
							<h3 align="center" class="mt-3 mb-3">Result List</h3>	  
					<!-- result start-->
                    
								<table class="table table-hover">
									<thead>
										<tr>
											<th>ID:</th>
											<th>Name:</th>
											<th>Mark:</th>
											<th>Marit Position:</th>
										</tr>
									</thead>
									<tbody>
										<?php
										if($results){
											foreach($results as $rs){
												?>
										<tr>
											<td><?= $rs->id ?></td>
											<td><?= $rs->name ?></td>
											<td><?= $rs->obtainmark ?></td>
											<td><?= $rs->position ?></td>
										</tr>
										<?php	}
										} ?>

									</tbody>
								</table>
                    

					<!-- result end-->
			</div>
		</div>	
	</section>	
		
			<!-- Jquery -->
			<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
			<!-- bootstrap -->
			<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/js/bootstrap.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
			<!-- carousel -->
			<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js"></script>	
			<script src="assets/js/bs-init.js"></script>	
</body>
</html>
